<?php
// Удаление папки auth
function rrmdir($dir) {
  if (is_dir($dir)) {
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
      (is_dir("$dir/$file")) ? rrmdir("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
  }
  return false;
}

rrmdir('auth');
header('Location: bot_dashboard.php');