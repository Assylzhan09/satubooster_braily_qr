<?php
// Удаление auth/ при отключении
if (isset($_GET['disconnect'])) {
    function rrmdir($dir) {
        if (is_dir($dir)) {
            foreach (scandir($dir) as $object) {
                if ($object !== "." && $object !== "..") {
                    $path = $dir . "/" . $object;
                    is_dir($path) ? rrmdir($path) : unlink($path);
                }
            }
            rmdir($dir);
        }
    }
    rrmdir(__DIR__ . '/auth');
    echo "<script>alert('✅ Бот өшірілген. Қайта қосу node index.js'); location.href='bot_dashboard.php';</script>";
    exit;
}

// Обновление статуса заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id = $_POST['order_id'];
    $newStatus = $_POST['new_status'];
    $pdo = new PDO("mysql:host=localhost:3306;dbname=satuboos_ter_antitarakan_partner;charset=utf8", "satuboos_ter_antitarakan_partner", "satuboos_ter_antitarakan_partner");
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$newStatus, $id]);
    header("Location: bot_dashboard.php");
    exit;
}

$pdo = new PDO("mysql:host=localhost:3306;dbname=satuboos_ter_antitarakan_partner;charset=utf8", "satuboos_ter_antitarakan_partner", "satuboos_ter_antitarakan_partner");
$orders = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>🤖 WhatsApp Бот | TazaLike</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f0f2f5;
    }

    header {
      background: #0a5;
      color: white;
      padding: 15px;
      text-align: center;
    }

    header img {
      height: 40px;
      vertical-align: middle;
    }

    .container {
      max-width: 800px;
      margin: auto;
      padding: 20px;
    }

    .hidden-buttons {
      display: none;
      flex-direction: column;
      gap: 10px;
      margin-bottom: 20px;
    }

    .card {
      background: white;
      padding: 15px;
      margin: 10px 0;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    .card h3 {
      margin: 0 0 10px;
    }

    .status-new { color: blue; }
    .status-подтвержден { color: orange; }
    .status-отправлен { color: green; }
    .status-доставлен { color: gray; }

    .main-button {
      background: #0a5;
      color: white;
      border: none;
      padding: 12px;
      width: 100%;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      margin-bottom: 10px;
    }

    .danger {
      background: #d9534f;
    }

    .qr-box {
      text-align: center;
      margin: 20px 0;
    }

    @media (max-width: 600px) {
      .container {
        padding: 10px;
      }

      .main-button {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>

<header>
  <img src="https://satucrm.satubooster.kz/antitarakan-partner/logo.png" alt="Logo"> 🤖 TazaLike Бот
</header>

<div class="container">
  <button class="main-button" onclick="toggleButtons()">⚙️ Ашу</button>

  <div class="hidden-buttons" id="bot-actions">
    <form method="post" action="restart_bot.php">
      <button class="main-button">🔄 Ботты қайта қосу (жаңа QR)</button>
    </form>
    <form method="get" onsubmit="return confirm('Вы уверены, что хотите отключить бота?')">
      <button class="main-button danger" name="disconnect" value="1">⛔ Отключить бота</button>
    </form>
  </div>

  <div class="qr-box" id="qr">📷 Жүктелуде QR-кода...</div>

  <h2>📦 Тапсырыстар</h2>
  <?php if (empty($orders)): ?>
    <p>Тапсырыстар жоқ.</p>
  <?php else: ?>
    <?php foreach ($orders as $order): ?>
      <div class="card">
        <h3>📞 <?= htmlspecialchars($order['phone']) ?></h3>
        <p><strong>Тапсырыс жайлы:</strong><br><?= nl2br(htmlspecialchars($order['comment'])) ?></p>
        <?php if (!empty($order['file_path'])): ?>
          <p><a href="<?= htmlspecialchars($order['file_path']) ?>" target="_blank">📎 Чек (файл)</a></p>
        <?php endif; ?>
        <p><strong>Дата:</strong> <?= $order['created_at'] ?></p>
        <p><strong>Статус:</strong> <span class="status-<?= $order['status'] ?>"><?= $order['status'] ?: 'новый' ?></span></p>
        <form method="post">
          <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
          <select name="new_status">
            <option value="подтвержден">✅ Қабылданған</option>
            <option value="отправлен">🚚 Жіберілген</option>
            <option value="доставлен">📦 Жеткізілген</option>
          </select>
          <button name="update_status">💾 САҚТАУ</button>
        </form>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<script>
function toggleButtons() {
  const block = document.getElementById('bot-actions');
  block.style.display = block.style.display === 'flex' ? 'none' : 'flex';
}

fetch('get_qr.php')
  .then(res => res.json())
  .then(data => {
    if (data.qr) {
      const imgUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(data.qr);
      document.getElementById('qr').innerHTML = `<img src="${imgUrl}" alt="QR-код">`;
    } else {
      document.getElementById('qr').innerText = '❌ QR-код қате';
    }
  })
  .catch(() => {
    document.getElementById('qr').innerText = '❌ Қате пайда болды';
  });
</script>

</body>
</html>