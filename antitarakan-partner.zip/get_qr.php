<?php
header('Content-Type: application/json');
echo file_get_contents('http://194.32.141.216:3000/qr');