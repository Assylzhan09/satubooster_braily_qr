<?php
if (isset($_GET['qr'])) {
  $qrJson = file_get_contents('http://194.32.141.216:3000/qr');
  header('Content-Type: application/json');
  echo $qrJson;
  exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>WhatsApp QR-подключение</title>
  <style>
    body { font-family: sans-serif; text-align: center; margin-top: 40px; }
    button { font-size: 16px; padding: 10px 20px; }
    img { margin-top: 20px; border: 1px solid #ccc; }
  </style>
</head>
<body>
  <h2>Подключение WhatsApp (Baileys)</h2>
  <button onclick="getQR()">🔄 Открыть QR</button>
  <div id="qr-container"></div>

  <script>
    function getQR() {
	fetch('qr_panel.php?qr=1')
	.then(res => res.json())
        .then(data => {
          if (data.qr) {
            const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(data.qr)
            document.getElementById('qr-container').innerHTML = `<img src="${qrUrl}" alt="QR Code">`
          } else {
            document.getElementById('qr-container').innerHTML = 'QR-код недоступен'
          }
        })
        .catch(() => {
          document.getElementById('qr-container').innerHTML = '❌ Ошибка соединения с Node.js'
        });
    }
  </script>
</body>
</html>