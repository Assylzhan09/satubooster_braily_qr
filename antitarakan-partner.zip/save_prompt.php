<?php
$prompt = $_POST['prompt'] ?? '';
file_put_contents('settings.json', json_encode(['system_prompt' => $prompt], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
header('Location: bot_dashboard.php');