<?php
file_put_contents("check1.txt", "Webhook стартует\n", FILE_APPEND);

$raw = file_get_contents("php://input");
file_put_contents("log.txt", date("Y-m-d H:i:s") . ' | ' . $raw . "\n", FILE_APPEND);
$input = json_decode($raw, true);

$message = $input['entry'][0]['changes'][0]['value']['messages'][0] ?? null;
$from = $message['from'] ?? '';
$text = $message['text']['body'] ?? '';
$hasImage = isset($message['image']);
$hasDocument = isset($message['document']);
$hasAudio = isset($message['audio']['data']);
$isManager = $message['from_me'] ?? false; // Менеджер (бот) написал

file_put_contents("check_audio.txt", print_r($message['audio'] ?? [], true), FILE_APPEND);
file_put_contents("check2.txt", "FROM: $from\nTEXT: $text\n", FILE_APPEND);
if (!$from || (!$text && !$hasImage && !$hasDocument && !$hasAudio)) exit;

// === Если менеджер сам пишет — заблокировать ИИ на 15 минут ===
if ($isManager) {
    file_put_contents("blocked_$from.txt", time());
    exit;
}

function isBlocked($from) {
    $blockFile = "blocked_$from.txt";
    if (!file_exists($blockFile)) return false;
    $lastTime = (int)file_get_contents($blockFile);
    return (time() - $lastTime) < 900; // 15 минут
}

$images = [
    "https://satucrm.satubooster.kz/antitarakan-partner/img1.png",
    "https://satucrm.satubooster.kz/antitarakan-partner/img2.png",
    "https://satucrm.satubooster.kz/antitarakan-partner/img3.png"
];

$sentLog = 'sent_clients.txt';
$clients = file_exists($sentLog) ? file($sentLog, FILE_IGNORE_NEW_LINES) : [];
$firstTime = !in_array($from, $clients);

$baseUrl = "http://194.32.141.216:3000/send.php";

// === Обработка голосового ===
if ($hasAudio) {
    if (isBlocked($from)) exit;

    $audioData = base64_decode($message['audio']['data']);
    $file = "audio_" . time() . ".ogg";
    file_put_contents($file, $audioData);

    $apiKey = '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';
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => 'https://api.openai.com/v1/audio/transcriptions',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => [
            'file' => new CURLFile(realpath($file)),
            'model' => 'whisper-1',
            'language' => 'kk'
        ],
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $apiKey"
        ]
    ]);

    $response = curl_exec($curl);
    curl_close($curl);
    unlink($file);

    $result = json_decode($response, true);
    $recognizedText = $result['text'] ?? '';

    $reply = $recognizedText ? getAIReply($recognizedText, true) : "Кешіріңіз, дауыс анықталмады. Қайталап жазыңыз.";
    file_get_contents($baseUrl . "?to=" . urlencode($from) . "&text=" . urlencode($reply));
    exit;
}

// === Обработка оплаты и медиа ===
$normalized = mb_strtolower($text);
$paidWords = ['оплатил', 'перевел', 'скинул', 'каспи', 'kaspi', 'төледім', 'аудардым', 'чек', 'чекті', 'скрин', 'скриншот'];
foreach ($paidWords as $word) {
    if (strpos($normalized, $word) !== false) {
        $thankYou = "Рақмет! Біз жеткізуді бастаймыз.\nСпасибо! Начинаем доставку.";
        file_get_contents($baseUrl . "?to=" . urlencode($from) . "&text=" . urlencode($thankYou));
        exit;
    }
}
if ($hasImage || $hasDocument) {
    $thankYou = "Рақмет! Біз жеткізуді бастаймыз.\nСпасибо! Начинаем доставку.";
    file_get_contents($baseUrl . "?to=" . urlencode($from) . "&text=" . urlencode($thankYou));
    exit;
}

// === Фото по ключевым словам ===
$photoWords = ['фото', 'сурет', 'photo', 'көрсет', 'покажи', 'товар'];
foreach ($photoWords as $word) {
    if (strpos($normalized, $word) !== false) {
        $img = $images[array_rand($images)];
        file_get_contents($baseUrl . "?to=" . urlencode($from) . "&image=" . urlencode($img));
        break;
    }
}

// === Объединение сообщений и AI-ответ ===
$cacheFile = "pending_messages_$from.txt";
$now = time();

if ($text) {
    if (isBlocked($from)) exit;

    $combined = $text;
    $previous = [];

    if (file_exists($cacheFile)) {
        $previous = json_decode(file_get_contents($cacheFile), true) ?: [];
        $previous = array_filter($previous, fn($msg) => $now - $msg['time'] < 60);
    }

    $previous[] = ['text' => $text, 'time' => $now];
    file_put_contents($cacheFile, json_encode($previous));

    $combined = implode(" ", array_column($previous, 'text'));
	$reply = getAIReply($combined, $firstTime);

    unlink($cacheFile);
    file_get_contents($baseUrl . "?to=" . urlencode($from) . "&text=" . urlencode($reply));

//    if ($firstTime) {
//        $randomImage = $images[array_rand($images)];
//        file_get_contents($baseUrl . "?to=" . urlencode($from) . "&image=" . urlencode($randomImage));
//        file_put_contents($sentLog, $from . "\n", FILE_APPEND);
//    }
	if ($firstTime) {
		file_put_contents($sentLog, $from . "\n", FILE_APPEND);
	}
    exit;
}

// === Функция AI-ответа ===
function getAIReply($userText, $isReturningClient) {
    $apiKey = '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';

    $systemPrompt = <<<PROMPT
🧠 Роль:
Сен — "TazaLike" компаниясының кәсіби WhatsApp кеңесшісі-сатушысысың.

📦 Өнім туралы қысқаша:
Өнім: "Анти-Таракан" пастасы (тарақан, тышқан, құмырсқаға қарсы)

Көлемі: 250 г

Бағасы: 10 000 ₸(теңге)

Жеткізу: Қазақстан бойынша тегін

Төлем: Kaspi арқылы (алдын ала немесе кейін)

Кепілдік: 2 жыл әсер етеді

Скидка жоқ

Каспи Ред және Рассрочка бар

Өнім балалар мен жануарлар жетпейтін жерге жағылады

🔍 Негізгі артықшылықтар:
Иіссіз, адамға зиянсыз

Ұядағы жұмыртқа мен балаларына дейін жояды

Паста сары түсті смола боп қатып қалады, жайылып кетпейді

Бір жаққа жағу жеткілікті – 2 жыл бойы қорғайды

💬 Сөйлесу ережелері:
Клиент қазақша жазса – таза, ауызекі, дұрыс қазақша жаз

Ағылшыннан аударылған сияқты сөйлемдер қолданба

Бос сөздер мен жалпы сұрақтар қолданба:

❌ «Сізге қалай көмектесе аламын?»

❌ «Қандай сұрағыңыз бар?»

❌ «Басқа сұрақтарыңыз болса, айтыңыз.»

Клиентпен жылы, нақты, қысқа сөйлес

📸 Клиент сұраса:
Фото сұраса: «Қазір жіберемін» де

Дауыс жазса: «Қазір жауап беремін» де

💰 Төлем және тапсырыс:
Клиент дайын болса, сілтеме жібер: https://pay.kaspi.kz/pay/xshstvuj

Чек немесе скриншот сұра (онсыз жеткізу болмайды)

Егер күмәнданса:

Сапасын түсіндір

Басқалардан айырмашылығын айт

Отзыв айт

«Сізді бағасы ма ойлантып тұр?», «Жұмыс істемейді деп қорқасыз ба?» деп нақтыла

Оптом алушыларға бонус пен көтерме баға бар (бағаны айтпа)

⚠️ Тыйым салынған:
«Рақмет», «рахмет» деп бот сияқты жауап берме

Артық эмоция мен шаблон сөйлемдер қолданба

«Керемет», «тамаша» дегенге мақтай бер, бірақ нақты аргументтермен

✅ Міндетің:
Өнімді түсіндір

Сұраққа нақты жауап бер

Клиентті тапсырысқа итермеле

Аты-жөні мен мекенжайын сұра

Қажет болса – төлем сілтемесін жібер

Чек сұра

Соңғы ескерту:
Бот сияқты емес, адам сияқты сөйлес. Қысқа, қарапайым және логикалық жауап бер.

‼️ Назар аудар: Қандай жағдай болмасын, "Сәлем", "Здравствуйте" немесе басқа амандасу сөздерін жауаптың басында жазба! Тек өзі амандасса ғана амандас. Клиент қай тілде, қалай жазса да, амандасу сөзін қайтарма, бірден сұрағына жауап бер немесе қажетті ақпарат бер.
‼️ Назар аудар:
— Егер клиент қысқа жауап (я, ок, иә, мах, да, готов, болады, ия, ия, окей, закажу, дайынмын, тапсырыс берем, алдым, қабылдаймын және т.б.) жазса — және бұған дейін тапсырыс туралы сұралған болса, мұны растау деп қабылда.
— Бірақ, егер клиенттің жауабы контексттен бөлек, анық емес болса, "Бұл өнімді алғыңыз келе ме?" деп нақтылап сұра. 
— Контекстке қарай дұрыс реакция бер: заказ болғанда — адрес сұра, басқа жағдайда — көмегіңді ұсын.
- Егер клиент қоштасу сөзін жазса (“сау болыңыз”, “қош болыңыз”, “көріскенше”, “бай”, “пока”, “до свидания”, “қош”, “алғыс білдіремін” т.б.), сен де вежливо қоштасып жауап бер де, диалогты аяқта. Ешқандай өнім ұсынба, сұрақ қойма.

PROMPT;

    if ($isReturningClient) {
        $systemPrompt .= "\n\nКлиент бұрын жазса, онда қайтадан сәлем деп жазба. Клиент өзі амандасса ғана сен амандас, бірден сұрағына жауап бер.";
    }

    $data = [
        "model" => "gpt-4o",
        "temperature" => 0.7,
        "messages" => [
            ["role" => "system", "content" => $systemPrompt],
            ["role" => "user", "content" => $userText]
        ]
    ];

    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey"
        ],
        CURLOPT_POSTFIELDS => json_encode($data)
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $res = json_decode($response, true);
    return $res['choices'][0]['message']['content'] ?? 'Қайталап жазыңызшы.';
}